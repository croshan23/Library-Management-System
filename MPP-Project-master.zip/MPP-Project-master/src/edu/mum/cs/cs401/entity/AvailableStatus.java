package edu.mum.cs.cs401.entity;

public enum AvailableStatus {
	Available, Unavailable
}
