package edu.mum.cs.cs401.entity;

public enum Role {
	ADMIN, LIBRARIAN, MEMBER
}
